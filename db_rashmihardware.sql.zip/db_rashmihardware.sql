-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2017 at 05:59 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_rashmihardware`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nails`
--

CREATE TABLE IF NOT EXISTS `tbl_nails` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `Category` text NOT NULL,
  `Size` text NOT NULL,
  `Quantity` text NOT NULL,
  `ActualPrice` int(250) NOT NULL,
  `SellingPrice` int(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_nails`
--

INSERT INTO `tbl_nails` (`id`, `Category`, `Size`, `Quantity`, `ActualPrice`, `SellingPrice`) VALUES
(1, 'normalNail', '1 inch', '', 125, 200),
(2, 'Category', 'Size', 'Quantity', 0, 0),
(3, 'Category', 'Size', 'Quantity', 120, 200);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
